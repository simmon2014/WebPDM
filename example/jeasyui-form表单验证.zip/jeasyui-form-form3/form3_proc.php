<?php

$name = $_POST['name'];
$email = $_POST['email'];
$subject  = $_POST['subject'];
$message   = $_POST['message'];

echo "Name: $name <br/> Email: $email <br/> Subject: $subject <br/> Message:$message";

?>